/** Shared values for native ports. Apply platform text scaling and safe areas in the native layer. */
export const scamCheckerTokens = {
  "name": "Scam Checker",
  "version": "1.0.0",
  "direction": "02 — Precision",
  "description": "Semantic design tokens. Product color and interaction source for implementation. Native text scaling must remain enabled.",
  "color": {
    "light": {
      "canvas": "#F5F5F7",
      "surface": "#FFFFFF",
      "ink": "#15171C",
      "text": "#202228",
      "muted": "#626670",
      "divider": "#DFE1E7",
      "controlBorder": "#7A818F",
      "action": "#0866E8",
      "actionHover": "#0053C7",
      "onAction": "#FFFFFF",
      "tint": "#EDF3FD",
      "tintStrong": "#C6D9FA",
      "risk": "#A32D25",
      "riskSurface": "#FFF0EE",
      "caution": "#805600",
      "cautionSurface": "#FFF5DC",
      "information": "#17549D",
      "informationSurface": "#EDF4FF",
      "noObviousSigns": "#236A42",
      "noObviousSignsSurface": "#EAF6ED",
      "focus": "#0866E8"
    },
    "dark": {
      "canvas": "#101115",
      "surface": "#1A1C22",
      "ink": "#F5F6FA",
      "text": "#ECEEF4",
      "muted": "#B4BAC7",
      "divider": "#363B47",
      "controlBorder": "#8A92A2",
      "action": "#7AB1FF",
      "actionHover": "#A2C9FF",
      "onAction": "#101115",
      "tint": "#172B48",
      "tintStrong": "#29456B",
      "risk": "#FFB3A8",
      "riskSurface": "#3E2425",
      "caution": "#F2D08B",
      "cautionSurface": "#3B3321",
      "information": "#AFCEFF",
      "informationSurface": "#1C2D47",
      "noObviousSigns": "#9ED9B4",
      "noObviousSignsSurface": "#1D3428",
      "focus": "#93BFFF"
    }
  },
  "font": {
    "ui": "Inter",
    "optionalReadability": "Atkinson Hyperlegible Next",
    "nativeApple": "system font (SF Pro)",
    "nativeWindows": "Segoe UI",
    "weights": {
      "body": 400,
      "label": 500,
      "strong": 600
    }
  },
  "type": {
    "standard": {
      "body": 20,
      "supporting": 17,
      "title": 34,
      "display": 42,
      "lineHeight": 1.5
    },
    "large": {
      "body": 24,
      "supporting": 20,
      "title": 38,
      "display": 46,
      "lineHeight": 1.5
    }
  },
  "spacing": [
    4,
    8,
    12,
    16,
    20,
    24,
    32,
    40,
    48,
    64
  ],
  "radius": {
    "compact": 8,
    "control": 12,
    "card": 16,
    "panel": 20,
    "dialog": 24,
    "pill": 999
  },
  "target": {
    "primary": 56,
    "secondary": 56,
    "compactProduct": 48
  },
  "stroke": {
    "divider": 1,
    "icon": 1.7,
    "focus": 3,
    "focusOffset": 4
  },
  "motion": {
    "pressMs": 120,
    "controlMs": 180,
    "warningMs": 240,
    "panelMs": 280,
    "completionMs": 600,
    "chartMs": 900,
    "scanCycleMs": 1800,
    "staggerMs": 70,
    "easeOut": [
      0.2,
      0.8,
      0.2,
      1
    ],
    "travelPx": 8,
    "pressTravelPx": 1,
    "reduced": "Instant final state; no decorative loop; static progress label"
  },
  "breakpoints": {
    "compact": 600,
    "adaptive": 900,
    "wide": 1200
  },
  "content": {
    "detectionStates": [
      "likely-scam",
      "uncertain",
      "no-obvious-signs",
      "unavailable"
    ],
    "monitoringStates": [
      "off",
      "permission-needed",
      "on",
      "paused",
      "unavailable"
    ],
    "criticalResultAutoDismiss": false,
    "storeRealInputInPrototype": false
  }
} as const;
export type Appearance = keyof typeof scamCheckerTokens.color;
