/** Web/Electron helpers. Native apps should map these tokens to their platform animation APIs. */
export const motion = {
  press: 120, control: 180, warning: 240, panel: 280, completion: 600,
  chart: 900, stagger: 70, scan: 1800, easeOut: 'cubic-bezier(.2,.8,.2,1)',
} as const;

export function prefersReducedMotion(): boolean {
  return typeof window === 'undefined' || window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

/** Final state remains visible after cancellation; caller owns lifecycle cleanup. */
export function enterPanel(element: HTMLElement, reduced = false): () => void {
  if (reduced || prefersReducedMotion()) return () => {};
  const animation = element.animate([{ opacity: 0, transform: 'translateY(8px)' }, { opacity: 1, transform: 'translateY(0)' }], { duration: motion.panel, easing: motion.easeOut });
  return () => animation.cancel();
}

/** Repeating nonessential animations must also have a visible pause control. */
export function observeMotionPreference(callback: (reduced: boolean) => void): () => void {
  const query = window.matchMedia('(prefers-reduced-motion: reduce)');
  const onChange = () => callback(query.matches);
  query.addEventListener('change', onChange); onChange();
  return () => query.removeEventListener('change', onChange);
}

/** Background windows do not keep decorative animations running. */
export function pauseWhenHidden(animations: Animation[]): () => void {
  const pausedByUs = new Set<Animation>();
  const update = () => {
    if (document.hidden) animations.forEach(a => { if (a.playState === 'running') { pausedByUs.add(a); a.pause(); } });
    else { pausedByUs.forEach(a => { if (a.playState === 'paused') a.play(); }); pausedByUs.clear(); }
  };
  document.addEventListener('visibilitychange', update); update();
  return () => { document.removeEventListener('visibilitychange', update); pausedByUs.clear(); };
}
