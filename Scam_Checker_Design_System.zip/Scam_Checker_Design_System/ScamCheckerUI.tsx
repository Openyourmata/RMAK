import * as React from 'react';

export type Tone = 'likely-scam' | 'uncertain' | 'no-obvious-signs' | 'unavailable';
export type Variant = 'primary' | 'secondary' | 'tertiary' | 'danger';
const cx = (...values: (string | false | undefined)[]) => values.filter(Boolean).join(' ');
const toneClass: Record<Tone, string> = { 'likely-scam': 'risk', uncertain: 'caution', 'no-obvious-signs': 'success', unavailable: 'info' };

/** Wrap only the product UI. System text scaling must remain enabled. */
export function ScamCheckerTheme({ appearance = 'light', textSize = 'standard', reduceMotion = false, children, ...props }:
  React.HTMLAttributes<HTMLDivElement> & { appearance?: 'light' | 'dark'; textSize?: 'standard' | 'large'; reduceMotion?: boolean }) {
  return <div {...props} className={cx('sc-ui', props.className)} data-theme={appearance} data-text-size={textSize} data-reduce-motion={reduceMotion}>{children}</div>;
}

export function Icon({ name, ...props }: React.SVGProps<SVGSVGElement> & { name: 'check' | 'warning' | 'help' | 'info' | 'close' | 'message' | 'arrow' }) {
  const paths = {
    check: 'M5 12l4 4L19 6', warning: 'M12 3 22 21H2ZM12 9v5m0 3h.01',
    help: 'M9 9a3 3 0 0 1 6 0c0 2-3 2-3 4m0 3h.01', info: 'M12 11v6m0-10h.01',
    close: 'm6 6 12 12M6 18 18 6', message: 'M21 11a8 8 0 0 1-8 8H6l-4 3V11a9 9 0 0 1 19 0ZM7 9h10M7 13h6', arrow: 'M4 12h15m-5-5 5 5-5 5'
  };
  return <svg {...props} className={cx('sc-icon', props.className)} viewBox="0 0 24 24" aria-hidden="true" focusable="false">{(name === 'help' || name === 'info') && <circle cx="12" cy="12" r="9" />}<path d={paths[name]} /></svg>;
}

export const Button = React.forwardRef<HTMLButtonElement, React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; busy?: boolean; busyLabel?: string; icon?: React.ReactNode }>(
  function Button({ variant = 'primary', busy = false, busyLabel = 'Working…', icon, children, className, disabled, type = 'button', ...props }, ref) {
    return <button {...props} ref={ref} type={type} className={cx('sc-button', variant, className)} disabled={disabled || busy} aria-busy={busy || undefined}>{icon}<span>{busy ? busyLabel : children}</span></button>;
  }
);

type FieldBase = { label: string; help?: string; error?: string; wrapperClassName?: string };
export const Field = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement> & FieldBase>(
  function Field({ label, help, error, id, wrapperClassName, className, ...props }, ref) {
    const generated = React.useId(); const fieldId = id || generated;
    const described = [props['aria-describedby'], help && `${fieldId}-help`, error && `${fieldId}-error`].filter(Boolean).join(' ') || undefined;
    return <div className={cx('sc-field', wrapperClassName)}><label htmlFor={fieldId}>{label}</label><input {...props} ref={ref} id={fieldId} className={className} aria-invalid={!!error || undefined} aria-describedby={described} />{help && <p className="sc-help" id={`${fieldId}-help`}>{help}</p>}{error && <p className="sc-error" id={`${fieldId}-error`}>{error}</p>}</div>;
  }
);

export const Textarea = React.forwardRef<HTMLTextAreaElement, React.TextareaHTMLAttributes<HTMLTextAreaElement> & FieldBase>(
  function Textarea({ label, help, error, id, wrapperClassName, ...props }, ref) {
    const generated = React.useId(); const fieldId = id || generated;
    return <div className={cx('sc-field', wrapperClassName)}><label htmlFor={fieldId}>{label}</label><textarea {...props} ref={ref} id={fieldId} aria-invalid={!!error || undefined} aria-describedby={[props['aria-describedby'], help && `${fieldId}-help`, error && `${fieldId}-error`].filter(Boolean).join(' ') || undefined} />{help && <p className="sc-help" id={`${fieldId}-help`}>{help}</p>}{error && <p className="sc-error" id={`${fieldId}-error`}>{error}</p>}</div>;
  }
);

export function Switch({ label, description, checked, onCheckedChange, disabled = false }:
  { label: string; description?: string; checked: boolean; onCheckedChange: (checked: boolean) => void; disabled?: boolean }) {
  const id = React.useId();
  return <div className="sc-setting"><div><span id={id} className="sc-setting-label">{label}</span>{description && <p id={`${id}-help`} className="sc-help">{description}</p>}</div><button type="button" className="sc-switch" role="switch" aria-checked={checked} aria-labelledby={id} aria-describedby={description ? `${id}-help` : undefined} disabled={disabled} onClick={() => onCheckedChange(!checked)}><span /></button></div>;
}

export function StatusBadge({ tone, children }: { tone: Tone; children: React.ReactNode }) {
  const names = { 'likely-scam': 'warning', uncertain: 'help', 'no-obvious-signs': 'check', unavailable: 'info' } as const;
  return <span className={`sc-status ${toneClass[tone]}`}><Icon name={names[tone]} />{children}</span>;
}

export function ResultPanel({ tone, title, summary, reasons = [], nextStep, actions }:
  { tone: Tone; title: string; summary: string; reasons?: { title: string; detail?: string }[]; nextStep: string; actions: React.ReactNode }) {
  const titleId = React.useId();
  return <section aria-labelledby={titleId} className="sc-result"><div className={`sc-result-heading ${toneClass[tone]}`}><StatusBadge tone={tone}>{tone === 'likely-scam' ? 'Likely scam' : tone === 'uncertain' ? 'Uncertain' : tone === 'no-obvious-signs' ? 'No obvious signs' : 'Unavailable'}</StatusBadge><h1 id={titleId} tabIndex={-1}>{title}</h1><p>{summary}</p></div>{reasons.length > 0 && <><h2>What we noticed</h2><ul className="sc-reasons">{reasons.map((r, index) => <li key={index}><strong>{r.title}</strong>{r.detail && <p>{r.detail}</p>}</li>)}</ul></>}<div className="sc-next"><h2>What to do next</h2><p>{nextStep}</p></div><div className="sc-actions">{actions}</div><p className="sc-help">A checker can miss a scam or flag a genuine message.</p></section>;
}

/** Parent controls when to announce and deduplicates repeated captures. No focus stealing. */
export function Warning({ title, description, onDetails, onDismiss }:
  { title: string; description: string; onDetails: () => void; onDismiss: () => void }) {
  return <aside className="sc-warning" aria-label="Scam Checker warning"><p className="sc-wordmark">Scam Checker</p><h2>{title}</h2><p>{description}</p><div className="sc-stack"><Button onClick={onDetails}>Show me why</Button><Button variant="secondary" onClick={onDismiss}>Dismiss warning</Button></div><p className="sc-help">This warning does not close or change the page.</p></aside>;
}

/** Uses the native modal focus model; render inside ScamCheckerTheme. */
export function Dialog({ open, onOpenChange, title, children, actions }:
  { open: boolean; onOpenChange: (open: boolean) => void; title: string; children: React.ReactNode; actions?: React.ReactNode }) {
  const ref = React.useRef<HTMLDialogElement>(null); const titleId = React.useId();
  React.useEffect(() => {
    const d = ref.current; if (!d) return;
    const previous = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    if (open && !d.open) d.showModal(); else if (!open && d.open) d.close();
    return () => { if (d.open) d.close(); if (previous?.isConnected) previous.focus(); };
  }, [open]);
  return <dialog ref={ref} className="sc-dialog" aria-labelledby={titleId} onCancel={e => { e.preventDefault(); onOpenChange(false); }} onClose={() => { if (open) onOpenChange(false); }}><h2 id={titleId}>{title}</h2>{children}<div className="sc-actions">{actions}<Button variant="secondary" onClick={() => onOpenChange(false)}>Cancel</Button></div></dialog>;
}

export function Disclosure({ title, children }: { title: string; children: React.ReactNode }) {
  return <details className="sc-disclosure"><summary>{title}<span aria-hidden="true">⌄</span></summary><div>{children}</div></details>;
}

export function HistoryItem({ title, description, tone, onOpen }:
  { title: string; description: string; tone: Tone; onOpen: () => void }) {
  return <button type="button" className="sc-history-item" onClick={onOpen}><span className={`sc-history-icon ${toneClass[tone]}`}><Icon name={tone === 'likely-scam' ? 'warning' : tone === 'uncertain' ? 'help' : tone === 'unavailable' ? 'info' : 'check'} /></span><span><strong>{title}</strong><small>{description}</small></span><Icon name="arrow" /></button>;
}

export function EmptyState({ title, description, action }: { title: string; description: string; action: React.ReactNode }) {
  return <section className="sc-empty"><Icon name="message" /><h2>{title}</h2><p>{description}</p>{action}</section>;
}

export function CheckingState({ onCancel }: { onCancel: () => void }) {
  return <section className="sc-checking"><div className="sc-progress-line" aria-hidden="true" /><h1>Taking a closer look…</h1><p role="status">Looking for suspicious requests in this message.</p><Button variant="secondary" onClick={onCancel}>Cancel check</Button></section>;
}

export function Toast({ message, onDismiss }: { message: string; onDismiss: () => void }) {
  return <div className="sc-toast"><span role="status">{message}</span><Button variant="tertiary" onClick={onDismiss} aria-label="Dismiss message"><Icon name="close" /></Button></div>;
}

export function RadioGroup({ label, value, options, onChange }:
  { label: string; value: string; options: { value: string; label: string; description?: string }[]; onChange: (value: string) => void }) {
  const name = React.useId();
  return <fieldset className="sc-radios"><legend>{label}</legend>{options.map(option => <label className="sc-radio" key={option.value}><input type="radio" name={name} value={option.value} checked={value === option.value} onChange={() => onChange(option.value)} /><span><strong>{option.label}</strong>{option.description && <small>{option.description}</small>}</span></label>)}</fieldset>;
}

export function ScreenshotInput({ onChoose, error }: { onChoose: (file: File | null) => void; error?: string }) {
  const id = React.useId();
  return <div className="sc-field"><label htmlFor={id}>Choose a screenshot</label><input id={id} type="file" accept="image/png,image/jpeg,image/webp" aria-invalid={!!error || undefined} aria-describedby={`${id}-help${error ? ` ${id}-error` : ''}`} onChange={e => onChoose(e.currentTarget.files?.[0] || null)} /><p className="sc-help" id={`${id}-help`}>PNG, JPEG, or WebP. Up to 10 MB. Review before uploading.</p>{error && <p className="sc-error" id={`${id}-error`}>{error}</p>}</div>;
}

export function NavItem({ current, icon, children, ...props }:
  React.ButtonHTMLAttributes<HTMLButtonElement> & { current?: boolean; icon?: React.ReactNode }) {
  return <button {...props} type="button" className={cx('sc-nav-item', current && 'current', props.className)} aria-current={current ? 'page' : undefined}>{icon}<span>{children}</span></button>;
}
